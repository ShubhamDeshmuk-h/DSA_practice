public class prob3{
    public static void main(String[] args) {
        //problem was we have matrix 

        // get 4 variables and all will get small
        
        int[][] martix = new int[row][col];
        for (int i = 0; i < 10; i++) {
            for (int i = 0; i < 10; i++) {
                
            }
            
        }

        for(int i = 0;i<row;i++){

        }
        for (int i = 0; i < 10; i++) {
            
        }

        for (int i = 0; i < 10; i++) {
            
        }

        for (int i = 0; i < 10; i++) {
            
        }
    }
}